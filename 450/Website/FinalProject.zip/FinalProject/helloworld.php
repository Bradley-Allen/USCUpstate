<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Some PHP Embedded Inside HTML</title>
	</head>
	<body>
		<h1><?php echo "Hello World!"; ?></h1>
	</body>
	<footer>
		<a style="text-decoration: none; font-style: italic; color: gray;" href="index.html">[Return Home]</a>
	</footer>
</html>